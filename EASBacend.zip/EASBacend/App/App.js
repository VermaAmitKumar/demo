'use stric'
const express = require('express');
const _ = require('lodash')

const middleware = require('express-graphql')
const cors = require('cors');
const server = express();
const Schema = require('../schema/mainSchema')
server.use(cors());

server.use('/server', middleware({
  schema: Schema,
  pretty: true,
  graphiql: true
}))

const PORT = 8000;

server.listen(PORT, () => {
  console.info('##########################################################');
  console.info(`######                STARTING SERVER on ${PORT}       ######`);
  console.info('##########################################################\n');
});
