const Sequelize = require('sequelize');

const conn = new Sequelize('dbUsers', 'root', 'password', {
  host: 'localhost',
  dialect: 'mysql'
});




// conn.sync({ force: false }).then(() => {
//   console.log("UserTables created.")
// });


module.exports = {
  conn,
  Sequelize
};
