module.exports  = (conn, Sequelize) => {
  return conn.define('tbl_Employes', {
    Employeid: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    FullName: {
      type: Sequelize.STRING
    },
    Email: {
      type: Sequelize.STRING
    },
    Password: {
      type: Sequelize.STRING
    },
    gender: {
      type: Sequelize.STRING
    },
    RoleId: {
      type: Sequelize.INTEGER
    },
    createdby: {
      type: Sequelize.INTEGER,
    },
    updatedby: {
      type: Sequelize.INTEGER,
    },
    isDelete: {
      type: Sequelize.BOOLEAN, defaultValue: false
    }
  })
}