module.exports  = (conn, Sequelize) => {
  return conn.define('tbl_ProjectClientDetail', {
    ClientId: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    Name: {
      type: Sequelize.STRING
    },
    CountryId: {
      type: Sequelize.STRING
    },
    StateId: {
      type: Sequelize.STRING
    },
    CityId: {
      type: Sequelize.STRING
    },
    Discription: {
      type: Sequelize.STRING
    },
    createdby: {
      type: Sequelize.INTEGER,
    },
    updatedby: {
      type: Sequelize.INTEGER,
    },
    isDelete: {
      type: Sequelize.BOOLEAN, defaultValue: false
    }
  })
}