module.exports  = (conn, Sequelize) => {
  return conn.define('tbl_projectDetail', {
    ProjectId: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    ProjectName: {
      type: Sequelize.STRING
    },
    ClientId: {
      type: Sequelize.INTEGER
    },
    Discription: {
      type: Sequelize.STRING
    },
    createdby: {
      type: Sequelize.INTEGER,
    },
    updatedby: {
      type: Sequelize.INTEGER,
    },
    isDelete: {
      type: Sequelize.BOOLEAN, defaultValue: false
    }
  })
}