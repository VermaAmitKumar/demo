module.exports  = (conn, Sequelize) => {
  return conn.define('tbl_users', {
    RoleId: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    RoleName: {
      type: Sequelize.STRING
    },
    createdby: {
      type: Sequelize.INTEGER,
    },
    updatedby: {
      type: Sequelize.INTEGER,
    },
    isDelete: {
      type: Sequelize.BOOLEAN, defaultValue: false
    }
  })
}