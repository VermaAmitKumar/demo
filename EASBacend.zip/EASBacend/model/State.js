module.exports  = (conn, Sequelize) => {
  return conn.define('states', {
    StateId: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: {
      type: Sequelize.STRING
    },
    country_id: {
      type: Sequelize.INTEGER
    },
    createdby: {
      type: Sequelize.INTEGER,
    },
    updatedby: {
      type: Sequelize.INTEGER,
    },
    isDelete: {
      type: Sequelize.BOOLEAN, defaultValue: false
    }
  })
}