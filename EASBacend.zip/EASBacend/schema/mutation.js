const {GraphQLObjectType,  GraphQLString, GraphQLNonNull,GraphQLInt} = require('graphql');
const {User} = require('./userModel')
const conn = require('../confiq/dbconfiq');
const md5 = require('md5');
const Mutation = new GraphQLObjectType({
  name: 'Mutations',
  description: 'Functions to set stuff',
  fields() {
    return {
      addUser: {
        type: User,
        args: {
          name: {
            type: new GraphQLNonNull(GraphQLString)
          },
          gender: {
            type: new GraphQLNonNull(GraphQLString)
          },
          email: {
            type: new GraphQLNonNull(GraphQLString)
          },
          Password: {
            type: new GraphQLNonNull(GraphQLString)
          },
          Role: {
            type: new GraphQLNonNull(GraphQLInt)
          }
        },
        resolve(source, args) {
          args.Password=md5(args.Password)
          return conn.models.tbl_users.create(args);
        }
      }
    };
  }
});

module.exports = {
  Mutation
}