const {GraphQLObjectType, GraphQLNonNull, GraphQLList, GraphQLString} = require('graphql');
const md5 = require('md5');
var jwt = require('jsonwebtoken');
const {User, UserLogin} = require('./userModel')
const conn = require('../confiq/dbconfiq');
const Query = new GraphQLObjectType({
  name: 'Query',
  description: 'This is the root query',
  fields: () => {
    return {
      user: {
        type: new GraphQLList(User),
        resolve(root, args) {
          return conn.models.tbl_users.findAll();
        }
      },
      UserLogin: {
        type: new GraphQLList(UserLogin),
        args: {
          email: {
            type: new GraphQLNonNull(GraphQLString)
          },
          Password: {
            type: new GraphQLNonNull(GraphQLString)
          }
        },
        resolve(root, args) {
          args.Password = md5(args.Password);
          return conn.models.tbl_users.findOne({where: {email: args.email, Password: args.Password}}).then(result => {
            if (result) {
              return [{
                name: result.dataValues.name,
                token: jwt.sign({token: result.dataValues.name}, "shhhhh"),
                status: 200
              }]
            } else {
              return [{
                name: "null",
                token: "null",
                status: 401
              }]
            }
          })
        }
      }
    }
  }
})

module.exports = {
  Query
}
