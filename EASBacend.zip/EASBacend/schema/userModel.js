const {GraphQLObjectType, GraphQLInt, GraphQLString, GraphQLBoolean} = require('graphql');
const User = new GraphQLObjectType({
    name: 'UserMst',
    description: 'This represents a userMst',
    fields: () => {
    return {
      employeid: {
        type: GraphQLInt,
        resolve(tbl_users) {
          return tbl_users.id
        }
      },
      name: {
        type: GraphQLString,
        resolve(tbl_users) {
          return tbl_users.name
        }
      },
      email: {
        type: GraphQLString,
        resolve(tbl_users) {
          return tbl_users.email
        }
      },
      Password: {
        type: GraphQLString,
        resolve(tbl_users) {
          return tbl_users.Password
        }
      },
      gender: {
        type: GraphQLString,
        resolve(tbl_users) {
          return tbl_users.gender
        }
      },
      Role: {
        type: GraphQLInt,
        resolve(tbl_users) {
          return tbl_users.Role
        }
      },
      isDelete: {
        type: GraphQLBoolean,
        resolve(tbl_users) {
          return tbl_users.isDelete
        }
      }
    }
  }
})
const UserLogin = new GraphQLObjectType({
  name: 'UserLogin',
  description: 'This represents a userlogin',
  fields: () => {
    return {
      name: {
        type: GraphQLString
      },
      token:{
        type: GraphQLString,
      },
      status:{
        type: GraphQLInt,
      }
    }
  }
})
module.exports={User,UserLogin}