let CountryJsonData = require('./Data/Country.json');
let StateJsonData = require('./Data/state.json')
let CityJsonData = require('./Data/Cities.json')

const {conn, Sequelize} = require('./confiq/dbconfiq')

const EmployeModel = require('./model/Employe')
const CityModel = require('./model/CityModel')
const CountryModel = require('./model/Country')
const ProjectClientDetailModel = require('./model/ProjectClientDetailModel')
const ProjectDetailModel = require('./model/ProjectDetail')
const RoleModel = require('./model/RoleModel')
const StateModel = require('./model/State')

let countryM = CountryModel(conn, Sequelize)
let EmployeM = EmployeModel(conn, Sequelize)
let CityM = CityModel(conn, Sequelize)
let ProjectClientDetailM = ProjectClientDetailModel(conn, Sequelize)
let ProjectDetailM = ProjectDetailModel(conn, Sequelize)
let RoleM = RoleModel(conn, Sequelize)
let stateM = StateModel(conn, Sequelize)



conn.sync({force: false}).then(() => {
  console.log("Tables created.")
});

module.exports={
  countryM,
  EmployeM,
  CityM,
  ProjectClientDetailM,
  ProjectDetailM,
  RoleM,
  stateM
}
