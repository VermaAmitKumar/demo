import React, { Component } from 'react';
import { Modal, ModalHeader, ModalBody, ModalFooter, Button, Form, FormGroup, Label, Input } from 'reactstrap'

import { Mutation } from 'react-apollo';
import gql from 'graphql-tag';

const addUser = gql`
        mutation addUser($name: String!, $gender: String!,$email:String!) {
            addUser(name:$name,gender:$gender,email:$email) {
                id
                name
                gender
                email
            }
        }`;

class AddUser extends Component {
    state = {
        name: "",
        gender: "",
        email: "",
        isValidate:false
    }

    onhandle = () => {
        this.setState({
            name: "",
            gender: "",
            email: ""
        });
        this.props.toggle();
    }

    isValidate = () => {
        this.setState({isValidate:true});
    }
    render() {
        return (
            <Modal isOpen={this.props.isOpen} toggle={this.props.toggle}>
                <ModalHeader toggle={this.toggle}> Add New User</ModalHeader>
                <ModalBody>
                    <Form>
                        <FormGroup>
                            <Label>Enter User Name</Label>
                            <Input type="text" name="name" onChange={(e) => this.setState({ name: e.target.value })} value={this.state.name} />
                        </FormGroup>
                        {
                            (this.state.isValidate &&  this.state.name === "")?(
                                <span style={{ color: "red" }}>Name Field Required</span>
                            ):null
                        }
                        <FormGroup>
                            <Label>Enter User Email</Label>
                            <Input type="email" name="email" onChange={(e) => this.setState({ email: e.target.value })} value={this.state.email} />
                        </FormGroup>
                        {
                            (this.state.isValidate &&  this.state.email === "")?(
                                <span style={{ color: "red" }}>Email Field Required</span>
                            ):null
                        }
                        <FormGroup>
                            Select your gender:
                            <FormGroup check>
                                <Input type="radio" name="gender" value="Male" onChange={() => this.setState({ gender: "Male" })} />{" "}
                                Male
                            </FormGroup>
                            <FormGroup check>
                                <Input type="radio" name="gender" value="Female" onChange={() => this.setState({ gender: "Female" })} />{" "}
                                Female
                            </FormGroup>
                        </FormGroup>
                        {
                            (this.state.isValidate && this.state.gender === "")?(
                                <span style={{ color: "red" }}>Gender Field Required</span>
                            ):null
                        }
                    </Form>
                </ModalBody>
                <ModalFooter>
                        <Mutation mutation={addUser} variables={{ ...this.state }} onCompleted={this.onhandle}
                            update={(cache, { data: { addUser } }) => {
                                const { users } = cache.readQuery({ query: this.props.q,variables:{...this.props.pagination}});
                                const {countusers}=cache.readQuery({ query: this.props.count});
                                users.unshift(addUser);
                                cache.writeQuery({
                                    query: this.props.q,
                                    data: { users: users },
                                    variables:{...this.props.pagination}
                                });
                                cache.writeQuery({
                                    query: this.props.count,
                                    data: { countusers:countusers+1 }
                                });
                            }}>
                            {addUser => (
                                <Button color="primary" onClick={(this.state.name === "" || this.state.gender === "" || this.state.email === "" )?this.isValidate : addUser}>AddUser</Button>
                            )}
                        </Mutation>
                    <Button color="secondary" onClick={this.onhandle}>Cancel</Button>
                </ModalFooter>
            </Modal>
        );
    }
}

export default AddUser;
