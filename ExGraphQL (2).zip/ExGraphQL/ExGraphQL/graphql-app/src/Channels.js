import React from 'react';
import { Query } from 'react-apollo';
import gql from 'graphql-tag';
import { Table,Button} from 'reactstrap';

const Channel = () => {
    return (
        <div>
            <Table>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <Query query={gql`
                            {
                                channels{
                                    id
                                    name
                            }
                        }
                        `} >
                        {({ loading, error, data }) => {
                            if (loading) return <p>Loading</p>;
                            if (error) return <p>Error:(</p>;

                            return data.channels.map(({ id, name }) => (
                                <tr>
                                    <td>{`${id}`}</td>
                                    <td>{`${name}`}</td>
                                    <td>
                                        <Button color="primary">Edit</Button>&nbsp;&nbsp;
                                        <Button color="danger">Delete</Button>
                                    </td>
                                </tr>
                            ));
                        }}
                    </Query>
                </tbody>
            </Table>
        </div>

    );
}

export default Channel;