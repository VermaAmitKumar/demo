import React, { Component } from 'react';
import { Modal, ModalHeader, ModalBody, ModalFooter, Button, Form, FormGroup, Label, Input } from 'reactstrap'

import { Mutation } from 'react-apollo';
import gql from 'graphql-tag';

const UPDATE_USER = gql`
        mutation updateUser($id:Int!,$name: String!, $gender: String!,$email:String!) {
            updateUser(id:$id,name:$name,gender:$gender,email:$email){
                id,
                name,
                gender,
                email
              }  
        }`;

class EditUser extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id: "",
            name: '',
            gender: '',
            email: '',
            isValidate:false
        }
    }

    componentWillReceiveProps = (nextProps) => {
        this.setState({ id: parseInt(nextProps.user.id, 10), name: nextProps.user.name, gender: nextProps.user.gender, email: nextProps.user.email })
    }
    isValidate = () => {
        this.setState({isValidate:true});
    }

    render() {
        return (
            <Modal isOpen={this.props.isOpen} toggle={this.props.toggle}>
                <ModalHeader toggle={this.toggle}>Edit User</ModalHeader>
                <ModalBody>
                    <Form>
                        <FormGroup>
                            <Label>Enter User Name</Label>
                            <Input type="text" name="name" onChange={(e) => this.setState({ name: e.target.value })} value={this.state.name} />
                        </FormGroup>
                        {
                            (this.state.isValidate &&  this.state.name === "")?(
                                <span style={{ color: "red" }}>Name Field Required</span>
                            ):null
                        }
                        <FormGroup>
                            <Label>Enter User Email</Label>
                            <Input type="email" name="email" onChange={(e) => this.setState({ email: e.target.value })} value={this.state.email} />
                        </FormGroup>
                        {
                            (this.state.isValidate &&  this.state.email === "")?(
                                <span style={{ color: "red" }}>Email Field Required</span>
                            ):null
                        }
                        <FormGroup>
                            Select your gender:
                            <FormGroup check>
                                <Input type="radio" name="gender" defaultChecked={this.props.user.gender === "Male"} value="Male" onChange={() => this.setState({ gender: "Male" })} />{" "}
                                Male
                            </FormGroup>
                            <FormGroup check>
                                <Input type="radio" name="gender" defaultChecked={this.props.user.gender === "Female"} value="Female" onChange={() => this.setState({ gender: "Female" })} />{" "}
                                Female
                            </FormGroup>
                        </FormGroup>
                        {
                            (this.state.isValidate && this.state.gender === "")?(
                                <span style={{ color: "red" }}>Gender Field Required</span>
                            ):null
                        }
                    </Form>
                </ModalBody>
                <ModalFooter>
                        <Mutation mutation={UPDATE_USER} variables={{ ...this.state }} onCompleted={this.props.toggle}
                            update={(cache, { data: { updateUser } }) => {
                                const { users } = cache.readQuery({ query: this.props.q ,variables:{...this.props.pagination} });
                                let i = users.findIndex(user => parseInt(user.id, 10) === this.state.id);
                                let { id, name, gender, email } = updateUser;
                                users[i] = { ...users[i], id, name, gender, email };
                                cache.writeQuery({
                                    query: this.props.q,
                                    data: { users: users },
                                    variables:{...this.props.pagination}
                                });
                            }}>
                            {updateUser => (
                                <Button color="primary" onClick={ (this.state.name === "" || this.state.gender === "" || this.state.email === "" )?this.isValidate :  updateUser}>EditUser</Button>
                            )}
                        </Mutation>
                    <Button color="secondary" onClick={this.props.toggle}>Cancel</Button>
                </ModalFooter>
            </Modal>
        );
    }
}

export default EditUser;
