
var users = require('./schemas/user.schema');

const channels = [{
    id: 1,
    name: 'soccer'
}, {
    id: 2,
    name: 'baseball'
}];

// const users =[{
//     id:1,
//     name:'Abc',
//     gender:'Female',
//     email:'abc@gmail.com'
// },{
//     id:2,
//     name:'Pqr',
//     gender:'Female',
//     email:'pqr@gmail.com'
// }]

let nextId = 3;
let nextUserId=3;

const resolvers = {
    Query: {
        channels: () => {
            return channels;
        },
        channel: (root, { id }) => {
            return channels.find(channel => channel.id === parseInt(id,10))
        },
        users:()=>{
            console.log("users::",users);
            return users;
        },
        user:(root,{id})=>{
            return users.find(user => user.id === parseInt(id,10))
        }
    },
    Mutation: {
        addChannel: (root, args) => {
            const newChannel = { id: nextId++, name: args.name };
            channels.push(newChannel);
            return newChannel;
        },
        updateChannel:(root,args)=>{
            i=channels.findIndex(user => user.id === parseInt(args.id,10))
            if(i !== -1 ){
                uchannelssers[i].name=args.name
                return channels[i]
            }
        },
        deleteChannel:(root,{id})=>{
            i=channels.findIndex(channel => channel.id === parseInt(id,10))
            if(i !== -1){
                var u=channels.splice(i,1); 
            }
            return u[0];
        },
        addUser: (root, args) => {
            const newUser = { id: nextUserId++, name: args.name ,gender:args.gender,email:args.email};
            users.push(newUser);
            return newUser;
        },
        updateUser:(root,args)=>{
            let {id,name,gender,email}=args
            i=users.findIndex(user => user.id === parseInt(args.id,10))
            if(i !== -1 ){
                name=name?name:users[i].name
                gender=gender?gender:users[i].gender
                email=email?email:users[i].email
                users[i]={...users[i],name,gender,email}
                return users[i]
            }
        },
        deleteUser:(root,{id})=>{
            i=users.findIndex(user => user.id === parseInt(id,10))
            if(i !== -1){
               var u=users.splice(i,1); 
               return u[0];
            }
            else{
                message={text:`User {id} is not found`}
                return message;
            }
        }
    }
};

module.exports = resolvers;
