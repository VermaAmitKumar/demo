const { GraphQLObjectType, GraphQLInt, GraphQLString, GraphQLList, GraphQLSchema, GraphQLNonNull, GraphQLBoolean } = require('graphql');
const conn = require('../sequelize');

const User = new GraphQLObjectType({
    name: 'User',
    description: 'This represents a user',
    fields: () => {
        return {
            id: {
                type: GraphQLInt,
                resolve(tbl_users) {
                    return tbl_users.id
                }
            },
            name: {
                type: GraphQLString,
                resolve(tbl_users) {
                    return tbl_users.name
                }
            },
            email: {
                type: GraphQLString,
                resolve(tbl_users) {
                    return tbl_users.email
                }
            },
            gender: {
                type: GraphQLString,
                resolve(tbl_users) {
                    return tbl_users.gender
                }
            },
            isDelete: {
                type: GraphQLBoolean,
                resolve(tbl_users) {
                    return tbl_users.isDelete
                }
            }
        }
    }
})

const Query = new GraphQLObjectType({
    name: 'Query',
    description: 'This is the root query',
    fields: () => {
        return {
            users: {
                type: new GraphQLList(User),
                args:{
                    rowsperpage:{
                        type:GraphQLInt
                    },
                    currentpage:{
                        type:GraphQLInt
                    }
                    
                },
                resolve(root,{rowsperpage,currentpage}) {
                    let offset = (currentpage - 1) * rowsperpage;
                    return conn.models.tbl_users.findAll( { offset: offset, limit: rowsperpage , where: { isDelete: false }  });
                }
            },
            user: {
                type: new GraphQLList(User),
                args: {
                    id: {
                        type: GraphQLInt
                    }
                },
                resolve(root, {id}) {
                    return conn.models.tbl_users.findAll({ where: {id:id} });
                }
            },
            countusers:{
                type:GraphQLInt,
                resolve(root,args){
                    return conn.models.tbl_users.count({where:{isDelete:false}})
                }
            }
        }
    }
})

const Mutation = new GraphQLObjectType({
    name: 'Mutations',
    description: 'Functions to set stuff',
    fields() {
        return {
            addUser: {
                type: User,
                args: {
                    name: {
                        type: new GraphQLNonNull(GraphQLString)
                    },
                    gender: {
                        type: new GraphQLNonNull(GraphQLString)
                    },
                    email: {
                        type: new GraphQLNonNull(GraphQLString)
                    }
                },
                resolve(source, args) {
                    return conn.models.tbl_users.create(args);
                }
            },
            updateUser: {
                type: User,
                args: {
                    id: {
                        type: new GraphQLNonNull(GraphQLInt)
                    },
                    name: {
                        type:GraphQLString
                    },
                    gender: {
                        type:GraphQLString
                    },
                    email: {
                        type:GraphQLString
                    }
                },
                resolve(source, {id,name,gender,email,isDelete}) {
                    conn.models.tbl_users.update({ name,gender,email },{ where:{id:id,isDelete:false}});
                    return {id,name,gender,email,isDelete};
                }
            },
            deleteUser: {
                type: User,
                args: {
                    id: {
                        type: new GraphQLNonNull(GraphQLInt)
                    }
                },  
                resolve(source, {id}) {
                    conn.models.tbl_users.update({ isDelete:true },{ where:{id:id} });
                    return {id};
                }
            }
        };
    }
});

const Schema = new GraphQLSchema({
    query: Query,
    mutation: Mutation
})

module.exports = Schema;