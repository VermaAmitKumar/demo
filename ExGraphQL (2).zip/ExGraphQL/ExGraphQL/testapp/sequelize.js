const Sequelize = require('sequelize');

const conn = new Sequelize('db_users', 'root', 'password', {
  host: 'localhost',
  dialect: 'mysql'
});

const User = conn.define('tbl_users', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: { type: Sequelize.STRING },
  email: { type: Sequelize.STRING },
  gender: { type: Sequelize.STRING },
  isDelete: {
    type: Sequelize.BOOLEAN,
    defaultValue: false
  }
})

conn.sync({ force: false }).then(() => {
  console.log("Tables created.")
});


module.exports = conn;
