import React from 'react';
import ApolloClient from 'apollo-boost'
import { ApolloProvider } from 'react-apollo';
//import Channels from './Channels'
import Users from './Users'

const client = new ApolloClient({
  uri: "http://localhost:4000/"
})

const App = () => (
  <ApolloProvider client={client}>
    {/* <center> */}
      <div>
        {/* <h2>Channels Details</h2>
        <Channels></Channels> */}
        <h2>Users Details</h2>
        <Users></Users>
      </div>
    {/* </center> */}
  </ApolloProvider>
)
export default App;
