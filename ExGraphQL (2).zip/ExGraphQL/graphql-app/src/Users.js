import React, { Component } from 'react'
import { Query, Mutation } from 'react-apollo';
import gql from 'graphql-tag';
import { Table, Button, Input, Pagination } from 'reactstrap';
import 'antd/dist/antd.css';
import { Popconfirm, message } from 'antd';

import AddUser from './AddUser';
import EditUser from './EditUser';

const DISPLAY_USERS = gql`
    query getallUsers($rowsperpage:Int!,$currentpage:Int!){
        users(rowsperpage:$rowsperpage,currentpage:$currentpage){
            id
            name
            gender
            email
        }
    }`

const DELETE_USER = gql`
        mutation deleteUser($id: Int!) {
            deleteUser(id:$id) {
                id
                name
                gender
                email
            }
        }`;

const COUNT_USERS = gql`
    query countuser{
        countusers
    }
`;

class Users extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modal: false,
            editmodal: false,
            editUser: {},
            pagination: {
                rowsperpage: 5,
                currentpage: 1
            }
        }
        this.toggle = this.toggle.bind(this);
        this.toggleedit = this.toggleedit.bind(this);
    }
    toggle() {
        this.setState({ modal: !this.state.modal });
    }
    toggleedit() {
        this.setState({ editmodal: !this.state.editmodal });
    }

    changepage(e) {
        let { pagination } = this.state;
        this.setState({ pagination: { ...pagination, currentpage: parseInt(e.target.value, 10) } });
    }
    onchangeNrecord(e) {
        let { pagination } = this.state;
        this.setState({ pagination: { ...pagination, rowsperpage: parseInt(e.target.value, 10),currentpage:1 } });
    }

    render() {
        let {currentpage, rowsperpage } = this.state.pagination;
        let v=[];
        return (
            <div>
                <Button color="success" onClick={this.toggle} style={{ float: "right",marginRight:" 110px",marginBottom: "16px"}}>Add User</Button>
                <AddUser isOpen={this.state.modal} toggle={this.toggle} pagination={this.state.pagination} count={COUNT_USERS} q={DISPLAY_USERS}>AddUser</AddUser>
                <EditUser isOpen={this.state.editmodal} toggle={this.toggleedit} pagination={this.state.pagination} q={DISPLAY_USERS} user={this.state.editUser}></EditUser>
                <div className='pagenumber' style={{ float: "right" }}>
                    Show entries
                    <Input type="select" name="select" onChange={this.onchangeNrecord.bind(this)} style={{ width: "auto", float: "right", marginRight: "17px", marginLeft: "18px" }}>
                        <option value="5">5</option>
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                    </Input>
                </div>
                <Table striped>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Gender</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <Query query={DISPLAY_USERS}
                            variables={{ ...this.state.pagination }}
                        >
                            {({ loading, error, data }) => {
                                if (loading) return <tr><td colSpan="5" style={{textAlign:"center"}}>Loading to connect database</td></tr>
                                if (error) return <tr><td colSpan="5" style={{textAlign:"center"}}> Error to connect</td></tr>
                                if(data.users.length === 0)
                                    return <tr><td colSpan="5" style={{textAlign:"center"}}> Unable to connect</td></tr>
                                return data.users.map((user, key) => {
                                    if(key === rowsperpage)
                                        return null;
                                    return(<tr key={user.id}>
                                        <th scope="row">{`${key + 1}`}</th>
                                        <td>{`${user.name}`}</td>
                                        <td>{`${user.gender}`}</td>
                                        <td>{`${user.email}`}</td>
                                        <td>
                                            <Button color="primary" onClick={() => this.setState({ editUser: { ...user }, editmodal: true })}>Edit</Button>&nbsp;&nbsp;
                                            <Mutation mutation={DELETE_USER} variables={{ id: parseInt(user.id, 10) }} onCompleted={() => message.success('Successfully deleted :) !', 3)}
                                                update={(cache, { data: { deleteUser } }) => {
                                                    const { users } = cache.readQuery({ query: DISPLAY_USERS, variables:{...this.state.pagination} });
                                                    console.log("users::",(users.length-1));
                                                    let {currentpage,rowsperpage}=this.state.pagination;
                                                    if((users.length-1) === 0){
                                                        let { pagination } = this.state;
                                                        this.setState({ pagination: { ...pagination, currentpage:1 } });
                                                        currentpage=1;
                                                    }
                                                    cache.writeQuery({
                                                        query: DISPLAY_USERS,
                                                        data: { users: users.filter(user => parseInt(user.id, 10) !== parseInt(deleteUser.id, 10)) },
                                                        variables:{currentpage:currentpage,rowsperpage:rowsperpage}
                                                    });
                                                }}>
                                                {deleteUser => (
                                                    <Popconfirm title="Are you sure delete this record?" onConfirm={deleteUser} okText="Yes" cancelText="No">
                                                        <Button color="danger">Delete</Button>
                                                    </Popconfirm>
                                                )}
                                            </Mutation>
                                        </td>
                                    </tr>)});
                            }}
                        </Query>
                    </tbody>
                </Table>

                <center>
                    <div>
                        <Pagination aria-label="Page navigation example" style={{display:"block"}}>
                            <Query query={COUNT_USERS}>
                                {({ loading, error, data }) => {
                                    if (loading) return null
                                    if (error) return null
                                    let count = data.countusers;
                                    let btn = [];
                                    let totalpages = Math.ceil(count / rowsperpage);
                                    if (currentpage > totalpages) {
                                        currentpage = totalpages;
                                    }
                                    if (currentpage < 1) {
                                        currentpage = 1;
                                    }
                                    if (currentpage > 1) {
                                        v=(<Button outline color="primary" key="prevfirst" value="1" onClick={this.changepage.bind(this)}> {"<<"} </Button>)
                                        btn.push(v);
                                        v=(<Button outline color="primary" key="prevone" value={currentpage - 1} onClick={this.changepage.bind(this)}>{"<"} </Button>)
                                        btn.push(v);
                                    }
                                    let x = (currentpage - rowsperpage);
                                    while (x < ((currentpage + rowsperpage) + 1)) {
                                        let v = "";
                                        if ((x > 0) && (x <= totalpages)) {
                                            if (x === currentpage) {
                                                v = (<Button color="primary" key={x} value={x}>{x}</Button>);
                                            }
                                            else {
                                                v = (<Button outline color="primary" key={x} onClick={this.changepage.bind(this)} value={x}>{x}</Button>);
                                            }
                                        }
                                        btn.push(v);
                                        x++;
                                    }
                                    if (currentpage !== totalpages) {
                                        let nextpage = currentpage + 1;
                                        v = (<Button outline color="primary" value={nextpage} key="nextpage" onClick={this.changepage.bind(this)}> {">>"} </Button>);
                                        btn.push(v);
                                        v = (<Button outline color="primary" value={totalpages} key="nextlast" onClick={this.changepage.bind(this)}>{">"} </Button>);
                                        btn.push(v);
                                    }
                                    return btn;
                                }}
                            </Query>
                            {/* {buttondata} */}
                        </Pagination>
                    </div>
                </center>
            </div >
        );
    }
}

export default Users;
