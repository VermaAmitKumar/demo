const Sequelize = require('sequelize');
const Option = Sequelize.Op;

exports.mysql = new Sequelize('db_Users', 'root','root',{
    host: 'localhost',
    port: 3306,
    password:'root',
    dialect: 'mysql',
    operatorsAliases: Option,
});
if (exports.mysql) {
    console.log("connected");
}else{
    console.log("not connected")
}

