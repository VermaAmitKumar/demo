export const getGallery = () => ({
    type: 'GET_GALLERY',
});


