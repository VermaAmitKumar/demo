import React, {Component} from 'react';
import './App.css';
import NewsItem from '../ViewImageGallery/Index';

class App extends Component {
    render() {
        return (
            <div className="App">
                <h1>Image Gallery</h1>
                <div>
                    <NewsItem />
                </div>

            </div>
        );
    }
}


// App = connect(mapStateToProps,mapDispatchToProps)(App)

export default App;
