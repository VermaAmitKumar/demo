import React, {Component} from 'react';
import {connect} from 'react-redux'
import {getGallery} from '../../ACTION';
import './viewGallery.css'

class ViewAlbumsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            getGalleryDATA: [],
            pre: 0,
            next: 8,
            selectedImages: [],
            favrateImage: []
        }
    }

    componentWillReceiveProps(nextProps, nextContext) {
        const {pre, next} = this.state
        if (nextProps.getAllData) {
            this.setState({getGalleryDATA: nextProps.getAllData.slice(pre, next)})
        }
    }

    componentDidMount() {
        this.props.getGalleryDATA()
    }

    setctedImagesHandler = (data) => {
        let {selectedImages} = this.state
        selectedImages.push(data)
        this.setState({selectedImages})
    }
    pagination = (e) => {
        let {pre, next} = this.state
        if (e === "Prev") {
            if (pre === 0) {
                pre = 0
            } else {
                pre = pre - 8
                next = next - 8
            }
        } else if (e === "next") {
            if (next === 0) {
                next = 8
            } else {
                pre = pre + 8
                next = next + 8
            }
        }
        const data = this.props.getAllData.slice(pre, next)
        this.setState({
            pre, next, getGalleryDATA: data
        })
    }
    prevewImage = (data) => {
        debugger
        var modal = document.getElementById("myModal");

        // var img = document.getElementById("myImg");
        var modalImg = document.getElementById("img01");
        // var captionText = document.getElementById("caption");

        modal.style.display = "block";
        modalImg.src = data.thumbnailUrl;
        // captionText.innerHTML = this.alt;

    }
    modelClose = () => {
        var modal = document.getElementById("myModal");
        modal.style.display = "none";
    }
    favroteImageHandler = (data) => {
        let {favrateImage} = this.state
        favrateImage.push(data.id)
        this.setState({favrateImage})
        alert("image added successfully in favorite")
    }
    openfavroteImage=(data)=>{
        debugger
        var modal = document.getElementById("myModal1");
        modal.style.display = "block";

    }
    render() {
        console.log("=============================================>",this.state)
        const {getAllData, Loading} = this.props
        const {getGalleryDATA,favrateImage ,selectedImages} = this.state
        console.log("selectedImages", this.state)
        return <div>
            {Loading ? <div className="spinner-border"></div> :
                <div className="container">

                    <div className="row gallery-bottom">
                        <div className="col-sm-4">
                            <ul className="pagination">
                                <li>
                                    <div aria-label="Previous" value="prev" onClick={() => this.pagination("Prev")}>
                                        « Prev
                                    </div>
                                </li>

                                <li>
                                    <div aria-label="Next" onClick={() => this.pagination("next")}>
                                        Next »
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div className="col-sm-3 text-right">
                            <em>Displaying {this.state.pre} to {this.state.next}(of {this.props.getAllData && this.props.getAllData.length} posts)</em>
                        </div>
                        <div className="col-sm-3 text-right">
                            <button type="button" className="btn btn-primary" data-toggle="modal" data-target="#myModal" onClick={this.openfavroteImage}>View favorite Images</button>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-md-8">
                            <div id="grid" className="row">
                                {getGalleryDATA && getGalleryDATA.map(data => {
                                    return <div className="mix col-sm-3 page4  margin30">
                                        <div className="item-img-wrap ">
                                            <input type="checkbox" name="vehicle1" value="Bike"
                                                   onClick={() => this.setctedImagesHandler(data)}/>
                                            {favrateImage && !favrateImage.includes(data.id)?
                                            <i className="fa fa-heart withoutfavrotehart fa-2x" aria-hidden="true"
                                               onClick={() => this.favroteImageHandler(data)}></i>:<i className="fa fa-heart favrotehart fa-2x" aria-hidden="true"
                                                                                                      onClick={() => this.favroteImageHandler(data)}></i>}
                                            <img src={data.thumbnailUrl} className="img-responsive "
                                                 alt="workimg" onClick={() => this.prevewImage(data)}/>
                                        </div>
                                    </div>
                                })}

                            </div>
                        </div>

                        <div className="col-md-4">
                            <div id="grid" className="row selected_images">
                                <h1>Selected Images</h1>
                            </div>
                            <div id="grid" className="row">
                                {selectedImages && selectedImages.map(data => {
                                    return <div className="mix col-sm-4 page4  margin30">
                                        <div className="item-img-wrap ">
                                            <img src={data.thumbnailUrl} className="img-responsive"
                                                 alt="workimg"/>
                                        </div>
                                    </div>
                                })}
                            </div>
                        </div>
                    </div>
                </div>
            }

            <div id="myModal" className="modal">
                <span className="close" onClick={this.modelClose}>&times;</span>
                <img className="modal-content " id="img01" src={"https://www.w3schools.com/howto/img_snow.jpg"}
                     width={"10%"}/>
                <div id="caption"></div>
            </div>


            <div id="myModal1" className="modal fade" role="dialog">
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                            <h4 className="modal-title">Modal Header</h4>
                        </div>
                        <div className="modal-body">
                            <p>Some text in the modal.</p>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>


        </div>

    }
}


const mapDispatchToProps = {
    getGalleryDATA: getGallery,
};
const mapStateToProps = (state) => ({
    getAllData: state.AlBumsData,
    Loading: state.loading
})
ViewAlbumsList = connect(mapStateToProps, mapDispatchToProps)(ViewAlbumsList)
export default ViewAlbumsList;
