import { put, takeLatest, all } from 'redux-saga/effects';
import axios from 'axios'
function* fetchNews() {
    const json = yield axios.get('https://jsonplaceholder.typicode.com/photos')
    yield put({ type: "NEWS_GALLERYRECEIVED", json: json.data });
}
function* actionWatcher() {
    yield takeLatest('GET_GALLERY', fetchNews)
}
export default function* rootSaga() {
    yield all([
        actionWatcher(),
    ]);
}
