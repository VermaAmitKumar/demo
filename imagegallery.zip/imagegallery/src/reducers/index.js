const reducer = (state = {}, action) => {
    switch (action.type) {
        case 'GET_GALLERY':
            return { ...state, loading: true };
        case 'NEWS_GALLERYRECEIVED':
            return { ...state, AlBumsData: action.json, loading: false }
        default:
            return state;
    }
};
export default reducer;
