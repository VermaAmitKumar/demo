import React, { Component } from 'react';
import './App.css';
import ApolloClient from "apollo-boost";
import { ApolloProvider } from "react-apollo";
import Category from './Category'
const client = new ApolloClient({
  uri: "http://localhost:4000"
})


class App extends Component {

  render() {
    return <ApolloProvider client={client}>
      <Category></Category>
    </ApolloProvider>
  }
};

export default (App);
