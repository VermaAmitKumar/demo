import React, { Component } from 'react';
import './App.css';
import { Button } from 'reactstrap';
import AddCategory from './addCategory'
import { graphql, compose } from 'react-apollo';
import { DISPLAY, DeleteCategory } from './Graphqlsighn/Demo'
class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modal: false,
            editdata: [],
            Category_id: 0,
            ds: ""
        };
        this.toggle = this.toggle.bind(this);
    }
    toggle() {
        this.setState(prevState => ({
            modal: !prevState.modal,
            editdata: ""
        }));
    }
    editdata(data) {
        this.setState(prevState => ({
            modal: !prevState.modal,
            editdata: data
        }));
    }
    deletedata(Category_id, e) {
        e.preventDefault();
        if (window.confirm("Want to delete?")) {
            this.props.DeleteCategory({
                variables: {
                    Category_id: Category_id
                },
                refetchQueries: [{ query: DISPLAY }]
            });
        }
    }
    render() {
        let data
        if (this.props.DISPLAY.CourceAll) {
            data = this.props.DISPLAY.CourceAll.map(data => {
                return (<tr key={data.Category_id}>
                    <td>{data.Category_Name}</td>
                    <td><button type="button" className="btn btn-primary" onClick={() => { this.editdata(data) }} >Edit</button>
                        &nbsp;&nbsp;
                         <button type="button" className="btn btn-danger" onClick={this.deletedata.bind(this, data.Category_id)}  >Delete</button>
                    </td>
                </tr>)
            });
        }
        return <div>
            <div className="col-md-12">
                <div className="row">
                    <div className="col-md-12">
                        <Button color="danger" onClick={this.toggle}>Add Category</Button>
                        <AddCategory modal={this.state.modal} toggle={this.toggle} editdata={this.state.editdata} q={DISPLAY} />
                    </div>
                </div>
                <table id="example" className="display" style={{ width: "100%" }}>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data}
                    </tbody>
                </table>
            </div>
        </div>
    }
};
export default compose(
    graphql(DeleteCategory, { name: "DeleteCategory" }),
    graphql(DISPLAY, { name: "DISPLAY" })
)(App)
