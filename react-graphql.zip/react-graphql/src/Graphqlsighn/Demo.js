import gql from 'graphql-tag';
const UpdateCategory = gql`
mutation UpdateCategory($Category_id:Int!,$Category_Name: String!, $active: Int!) {
    UpdateCource(Category_id:$Category_id,Category_Name:$Category_Name,active:$active) {
      Category_id
    }
    }`;

const AddCategory = gql`
mutation AddCategory($Category_Name: String!, $active: Int!) {
    addCource(Category_Name:$Category_Name,active:$active) {
      Category_id
      Category_Name
      active
    }
    }`;
 const DISPLAY = gql`
{
  CourceAll {
      Category_id
      Category_Name
      active
  }
}`
const DeleteCategory = gql`
mutation ($Category_id:Int!){
	DeleteCource(Category_id:$Category_id){
 text
  }
}`
export  {UpdateCategory,AddCategory,DISPLAY,DeleteCategory};