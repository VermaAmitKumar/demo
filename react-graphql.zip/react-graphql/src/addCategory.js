import React from 'react';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, FormGroup, Label, Form, Input } from 'reactstrap';
import { graphql, compose } from 'react-apollo';
import { UpdateCategory, AddCategory, DISPLAY } from './Graphqlsighn/Demo'


class ModalExample extends React.Component {
    state = {
        Category_id: 0,
        Category_Name: "",
        active: parseInt(1)
    }
    componentWillReceiveProps = (nextprops) => {
        if (nextprops.editdata !== this.props.editdata) {
            this.setState({
                Category_id: nextprops.editdata.Category_id,
                Category_Name: nextprops.editdata.Category_Name
            })
        }
    }
    UpdateCategory = (event) => {
        debugger
        console.log(this.props)
        event.preventDefault();
        this.props.UpdateCategory({
            variables: {
                ...this.state
            },
            refetchQueries: [{ query: DISPLAY }]
        });
        this.setState({ Category_id: "", Category_Name: "" })
        this.props.toggle()
    }
    submitdata = (event) => {
        debugger
        event.preventDefault();
        this.props.AddCategory({
            variables: {
                ...this.state
            },
            refetchQueries: [{ query: DISPLAY }]
        });
        this.setState({ Category_id: "", Category_Name: "" })
        this.props.toggle()
    }
    render() {
        return (
            <Modal isOpen={this.props.modal} toggle={this.props.toggle} className={this.props.className}>
                <ModalHeader toggle={this.props.toggle}>Modal title</ModalHeader>
                <ModalBody>
                    <Form>
                        <FormGroup>
                            <Label>Enter Category Name</Label>
                            <Input type="text" name="categoty name" onChange={(e) => this.setState({ Category_Name: e.target.value })} defaultValue={this.state.Category_Name} />
                        </FormGroup>
                    </Form>
                </ModalBody>
                <ModalFooter>
                    {this.props.editdata.length !== 0 ?
                        <Button color="primary" onClick={this.UpdateCategory.bind(this)}>Update</Button> :

                        <Button color="primary" onClick={this.submitdata.bind(this)}>submit</Button>
                    }
                    <Button color="secondary" onClick={this.props.toggle}>Cancel</Button>
                </ModalFooter>
            </Modal>
        );
    }
}
export default compose(
    graphql(DISPLAY, { name: "DISPLAY" })
    , graphql(UpdateCategory, { name: "UpdateCategory" }),
    graphql(AddCategory, { name: "AddCategory" })
)(ModalExample);